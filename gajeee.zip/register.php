<?php
session_start();
//$abc=require_once('admin/inc/config.php');
// If the values are posted, insert them into the database.

/*$host="localhost";
$user="root";
$password="";
$db="cms";
 

 $conn = mysqli_connect($host, $user, $password, $db) or die("cannot connect"); 
//mysqli_select_db($conn, $db) or die("cannot select DB");
*/
 include("admin/inc/connect.php");


if (isset($_POST['create-acc']) && !empty($_POST["email"]) && !empty($_POST["pass"])){
    $username = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];
    $phone=$_POST['phone'];
    $slquery = "SELECT * FROM tbl_customer WHERE email = '$email'";
    $selectresult = mysqli_query($conn, $slquery);

    if(mysqli_num_rows($selectresult)>0)
    {
         $msg = 'email already exists';
         echo "$msg";
    }
    elseif($password != $cpassword){
         $msg = "passwords doesn't match";
         echo "$msg";
    }
    else{
            /// Dev otp logic start
 

$rndno=rand(100000, 999999);//OTP generate

$message = urlencode("otp number.".$rndno);

$to=$_POST['email'];

$subject = "Onespace OTP";

$txt = "Hi ".$_POST['name'].",your OTP: ".$rndno."";

$headers = "From: devanshngholba@gmail.com";  

  mail($to,$subject,$txt,$headers);
  if(isset($_POST['create-acc']))
  {
  $_SESSION['reg_name']=$_POST['name'];
  $_SESSION['email']=$_POST['email'];
  $_SESSION['phone']=$_POST['phone'];
  $_SESSION['pass']=$_POST['pass'];
  $_SESSION['otp']=$rndno;
   header( "Location: otp.php" );
  } 


    ///dev otp logic end

        //      $pass = password_hash("$password", PASSWORD_DEFAULT);
        //   $query = "INSERT INTO tbl_customer (`name`, `email`,`phone`, `password`) VALUES ('$username', '$email','$phone','$pass')";
          
        //   if(!mysqli_query($conn, $query))
        //   {
        //      echo "not inserted";
        //      echo "Error: ".mysqli_error($conn);
        //   }
        //   else
        //   {
        //      header("location:otp.php");
        //   //   //echo "inserted"; 
        //   }
          
          }
  }
?>